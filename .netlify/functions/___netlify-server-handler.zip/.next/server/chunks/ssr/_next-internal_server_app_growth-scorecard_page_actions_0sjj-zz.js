module.exports=[53463,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_growth-scorecard_page_actions_0sjj-zz.js.map