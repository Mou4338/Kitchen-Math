module.exports=[94220,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurant_calculator-history_page_actions_1p-pycw.js.map