module.exports=[58357,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurant_guides_page_actions_13pcujs.js.map