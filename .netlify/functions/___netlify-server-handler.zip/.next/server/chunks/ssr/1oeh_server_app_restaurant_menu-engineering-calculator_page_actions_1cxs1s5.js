module.exports=[1428,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_restaurant_menu-engineering-calculator_page_actions_1cxs1s5.js.map