module.exports=[58302,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurant_about_page_actions_0otczwt.js.map