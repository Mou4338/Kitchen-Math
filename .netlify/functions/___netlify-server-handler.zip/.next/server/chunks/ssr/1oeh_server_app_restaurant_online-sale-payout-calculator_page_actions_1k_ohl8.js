module.exports=[67618,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_restaurant_online-sale-payout-calculator_page_actions_1k_ohl8.js.map