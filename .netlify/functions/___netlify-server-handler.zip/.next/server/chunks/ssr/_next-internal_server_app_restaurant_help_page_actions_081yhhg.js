module.exports=[6499,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurant_help_page_actions_081yhhg.js.map