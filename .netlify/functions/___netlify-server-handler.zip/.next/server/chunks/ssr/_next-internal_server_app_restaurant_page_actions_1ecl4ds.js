module.exports=[74526,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurant_page_actions_1ecl4ds.js.map