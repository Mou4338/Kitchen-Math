module.exports=[73866,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_restaurant_menu-pricing-calculator_page_actions_120xica.js.map