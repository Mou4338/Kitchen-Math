globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/OXGvimXJ_FBIAYKb-xrT6/_buildManifest.js",
    "static/OXGvimXJ_FBIAYKb-xrT6/_ssgManifest.js",
    "static/OXGvimXJ_FBIAYKb-xrT6/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2tswzwt7g9k6a.js",
    "static/chunks/22yw_xvmlqw8w.js",
    "static/chunks/36t-grv2qj3xl.js",
    "static/chunks/turbopack-0o8hbzlhww264.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
